import { Component } from '@angular/core';

@Component({
  selector: 'app-textsec1',
  templateUrl: './textsec1.component.html',
  styleUrls: ['./textsec1.component.css']
})
export class Textsec1Component {

}
